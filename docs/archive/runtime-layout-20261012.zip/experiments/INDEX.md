# 实验总索引

- [v01–v21 方法实验](methods/README.md)：统一的配置、精选结果与原始运行导航。
- [Benchmark 实验](benchmarks/README.md)：v5 校准与 V18 联合家族准入材料。
- [人工标注](annotations/)与[早期基线结果](results/)仍保持原位。
- [产物政策](README.md)。

原始运行仍在既有目录中，第四步另行整理。历史运行路径映射保留于 v17/v18/v19 目录；方法定义的新旧路径映射见 [methods/path-map.json](methods/path-map.json)。
