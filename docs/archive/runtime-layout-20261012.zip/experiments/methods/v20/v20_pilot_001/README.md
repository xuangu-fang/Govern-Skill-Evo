# v20_pilot_001

[返回 v20](../README.md)

## 已归位材料

- [config](config)

冻结配置和 JSON 结果保留原始字节；内部历史路径经兼容链接指向当前材料。配置状态不是新的完成声明。

## 原始运行材料

- [artifacts/.v20_pilot_001.replay.lock](../../../../artifacts/.v20_pilot_001.replay.lock)
- [artifacts/.v20_pilot_001_continuation.replay.lock](../../../../artifacts/.v20_pilot_001_continuation.replay.lock)
- [artifacts/.v20_pilot_001_continuation_grouping24k.replay.lock](../../../../artifacts/.v20_pilot_001_continuation_grouping24k.replay.lock)
- [artifacts/.v20_pilot_001_repaired.replay.lock](../../../../artifacts/.v20_pilot_001_repaired.replay.lock)
- [artifacts/v20_pilot_001](../../../../artifacts/v20_pilot_001)
- [artifacts/v20_pilot_001_continuation](../../../../artifacts/v20_pilot_001_continuation)
- [artifacts/v20_pilot_001_continuation_grouping24k](../../../../artifacts/v20_pilot_001_continuation_grouping24k)
- [artifacts/v20_pilot_001_preflight](../../../../artifacts/v20_pilot_001_preflight)
- [artifacts/v20_pilot_001_repaired](../../../../artifacts/v20_pilot_001_repaired)
