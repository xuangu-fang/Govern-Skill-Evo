# v17 方法实验

[全部方法](../README.md)

## 配置与精选材料

- [v17_formal_001](v17_formal_001/README.md)

## 方法说明与报告

[设计、协议与报告](../../../docs/methods/v17/README.md)

## 原始运行与历史材料

以下仅提供导航，文件保持原位。各行可能是同一实验的重试、分析或补充，不是独立实验次数。

- [experiments/v17/pilot/v17_compiler_pilot_001](../../v17/pilot/v17_compiler_pilot_001)
- [experiments/v17/pilot/v17_diagnosis_pilot_002](../../v17/pilot/v17_diagnosis_pilot_002)
- [experiments/v17/pilot/v17_diagnosis_prompt7_001](../../v17/pilot/v17_diagnosis_prompt7_001)
- [experiments/v17/pilot/v17_diagnosis_prompt7_analysis_001](../../v17/pilot/v17_diagnosis_prompt7_analysis_001)
- [experiments/v17/pilot/v17_editor_pilot_001](../../v17/pilot/v17_editor_pilot_001)
- [experiments/v17/pilot/v17_grouping_pilot_001](../../v17/pilot/v17_grouping_pilot_001)
- [experiments/v17/pilot/v17_grouping_pilot_002](../../v17/pilot/v17_grouping_pilot_002)
- [experiments/v17/pilot/v17_monitor_pilot_001](../../v17/pilot/v17_monitor_pilot_001)
- [experiments/v17/pilot/v17_monitor_preflight_001](../../v17/pilot/v17_monitor_preflight_001)
- [experiments/v17/formal/v17_formal_001](../../v17/formal/v17_formal_001)
- [experiments/archive/v17/_organization_audit](../../archive/v17/_organization_audit)
- [experiments/archive/v17/v17_diagnosis_analysis_001](../../archive/v17/v17_diagnosis_analysis_001)
- [experiments/archive/v17/v17_diagnosis_pilot_001](../../archive/v17/v17_diagnosis_pilot_001)
- [experiments/archive/v17/v17_diagnosis_prompt3_001](../../archive/v17/v17_diagnosis_prompt3_001)
- [experiments/archive/v17/v17_diagnosis_prompt3_analysis_001](../../archive/v17/v17_diagnosis_prompt3_analysis_001)
- [experiments/archive/v17/v17_diagnosis_prompt3_g6_retry_001](../../archive/v17/v17_diagnosis_prompt3_g6_retry_001)
- [experiments/archive/v17/v17_diagnosis_prompt4_001](../../archive/v17/v17_diagnosis_prompt4_001)
- [experiments/archive/v17/v17_diagnosis_prompt4_analysis_001](../../archive/v17/v17_diagnosis_prompt4_analysis_001)
- [experiments/archive/v17/v17_diagnosis_prompt5_001](../../archive/v17/v17_diagnosis_prompt5_001)
- [experiments/archive/v17/v17_diagnosis_prompt5_analysis_001](../../archive/v17/v17_diagnosis_prompt5_analysis_001)
- [experiments/archive/v17/v17_diagnosis_retry_001](../../archive/v17/v17_diagnosis_retry_001)

先前运行目录索引：[experiments/v17/INDEX.md](../../v17/INDEX.md)
