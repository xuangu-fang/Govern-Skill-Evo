# autonomous_gse_v14

[返回 v14](../README.md)

## 已归位材料

- [config](config)

冻结配置和 JSON 结果保留原始字节；内部历史路径经兼容链接指向当前材料。配置状态不是新的完成声明。

## 原始运行材料

- [artifacts/autonomous_gse_v14](../../../../artifacts/autonomous_gse_v14)
- [artifacts/autonomous_gse_v14_tge_v1](../../../../artifacts/autonomous_gse_v14_tge_v1)
