# benchmark_v16_one_step_001

[返回 v16](../README.md)

## 已归位材料

- [GSE_V16_ONE_STEP_ADAPTATION_CONTRACT.md](GSE_V16_ONE_STEP_ADAPTATION_CONTRACT.md)
- [config](config)

冻结配置和 JSON 结果保留原始字节；内部历史路径经兼容链接指向当前材料。配置状态不是新的完成声明。

## 实现与原始运行

- [原实现目录（模块导入身份保留）](../../../../benchmarks/tau2_governed_evolution/editions/phase_final_candidate_day35/experiments/benchmark_v16_one_step_001)
- [原始运行与 Skill 产物（第四步处理）](../../../../benchmarks/tau2_governed_evolution/editions/phase_final_candidate_day35/experiments/benchmark_v16_one_step_001/run)
