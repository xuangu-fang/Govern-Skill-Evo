# v04 方法实验

[全部方法](../README.md)

## 配置与精选材料

- [autonomous_gse_v04_seed_100](autonomous_gse_v04_seed_100/README.md)
- [autonomous_gse_v04_seed_150](autonomous_gse_v04_seed_150/README.md)
- [autonomous_gse_v04_seed_200](autonomous_gse_v04_seed_200/README.md)

## 原始运行与历史材料

以下仅提供导航，文件保持原位。各行可能是同一实验的重试、分析或补充，不是独立实验次数。

- [artifacts/autonomous_gse_v04_seed_100](../../../artifacts/autonomous_gse_v04_seed_100)
- [artifacts/autonomous_gse_v04_seed_150](../../../artifacts/autonomous_gse_v04_seed_150)
- [artifacts/autonomous_gse_v04_seed_200](../../../artifacts/autonomous_gse_v04_seed_200)
