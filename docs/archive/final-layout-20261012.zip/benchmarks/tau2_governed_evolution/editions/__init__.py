"""Named benchmark editions."""
