# Benchmark 实验材料

保存用于构建、校准和评价 benchmark 的配置、冻结清单与精选结果。

- [v5](v5/README.md)：当前已从基准定义目录拆分。
- τ² 的历史内嵌实验暂留各 edition，入口见 [benchmark 总导航](../../benchmarks/README.md)；后续按依赖逐项迁移。

完整请求响应、轨迹、重试和日志进入 `artifacts/benchmarks/`，由 Git 忽略。必要的结果汇总与冻结证据保留在这里，不按 `results.json` 文件名统一忽略。
