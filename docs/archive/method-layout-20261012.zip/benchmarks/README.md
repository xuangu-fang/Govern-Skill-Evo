# Benchmark 系列与版本

按“研究系列 → edition”组织基准。方法 v18/v19/v20/v21 的版本号不属于此处的 benchmark 版本序列。

| 系列 | 版本入口 | 状态 |
|---|---|---|
| [τ² Governed Evolution](tau2_governed_evolution/README.md) | [8 个命名 editions](tau2_governed_evolution/editions/) | Governed 与 Phase 两条谱系，分别保留历史身份 |
| [Standalone](standalone/README.md) | [v5](standalone/editions/v5/README.md) | 独立合成原型，尚未冻结为正式任务集 |

## 内容归属

- `benchmarks/<系列>/editions/<版本>/`：基准定义、任务、划分、版本证据和原型入口。
- [experiments/benchmarks/v5](../experiments/benchmarks/v5/README.md)：v5 校准/探测/学习实验的协议、冻结清单、精选结果。
- [artifacts/benchmarks/v5](../artifacts/benchmarks/v5/)：本机完整运行产物，Git 忽略；克隆仓库后不一定存在。
- [docs/benchmarks/v5](../docs/benchmarks/v5/README.md)：设计、业务契约和研究报告。
- 源码与测试目前仍在 `src/benchmark_v5*`、`tests/benchmark_v5*`，Python 包名保持不变。

τ² 的 `shared/`、跨版本审计、构造材料与 V15/V16 内嵌实验保留原位。其中部分实现被后续方法调用；后续拆分需同步处理依赖，不能把历史目录当作可删除的运行输出。8 份 VERSION.json 和任务内容均未修改。

## 路径迁移与核验

[第 2 步整理记录](../docs/repository/BENCHMARK_LAYOUT.md) · [旧路径映射与摘要](path-map.json)

旧冻结清单中的路径和摘要保留原文；使用映射查阅当前文件，使用快照核对历史源码。快照匹配不等于当前源码仍与旧冻结版本相同。

```sh
python3 scripts/verify_benchmark_layout.py
python3 -m benchmarks.tau2_governed_evolution.validate_editions
```
