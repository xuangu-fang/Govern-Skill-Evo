# v12 方法实验

[全部方法](../README.md)

## 配置与精选材料

- [autonomous_gse_v12](autonomous_gse_v12/README.md)

## 原始运行与历史材料

实体材料已迁入 `artifacts/methods/`；旧入口仅作兼容。各行可能是同一实验的重试、分析或补充，不是独立实验次数。

- [artifacts/autonomous_gse_v12](../../../artifacts/methods/v12/autonomous_gse_v12)

[统一运行导航与新命令](../RUNTIME.md)
