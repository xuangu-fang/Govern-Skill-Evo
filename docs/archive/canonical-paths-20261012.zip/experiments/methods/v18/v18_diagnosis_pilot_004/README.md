# v18_diagnosis_pilot_004

[返回 v18](../README.md)

## 已归位材料

- [config](config)

冻结配置和 JSON 结果保留原始字节；内部历史路径经兼容链接指向当前材料。配置状态不是新的完成声明。
