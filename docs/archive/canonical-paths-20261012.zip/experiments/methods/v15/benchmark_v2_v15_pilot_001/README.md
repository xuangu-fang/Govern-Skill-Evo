# benchmark_v2_v15_pilot_001

[返回 v15](../README.md)

## 已归位材料

- [config](config)
- [reports](reports)

冻结配置和 JSON 结果保留原始字节；内部历史路径经兼容链接指向当前材料。配置状态不是新的完成声明。

## 实现与原始运行

- [原实现目录（模块导入身份保留）](../../../../benchmarks/tau2_governed_evolution/editions/phase_v2_day30/experiments/benchmark_v2_v15_pilot_001)
- [原始运行与 Skill 产物](../../../../artifacts/methods/v15/benchmark_v2_v15_pilot_001)

## 精选 Skill 产物

[各步 Parent、Candidate 和最终 Skill](results/skills)保持原字节；运行目录通过相对链接引用这些可版本管理的结果。
