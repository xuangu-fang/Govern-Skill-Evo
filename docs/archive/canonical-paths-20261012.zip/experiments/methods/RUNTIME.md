# 方法运行产物

[方法总索引](README.md) · [第四步整理记录](../../docs/repository/RUNTIME_LAYOUT.md) · [完整路径映射](runtime-path-map.json)

## 归属

- `experiments/methods/<版本>/<实验编号>/config/`：配置和冻结输入。
- 同一实验下的 `results/`、`reports/`：精选结果和研究报告。
- `artifacts/methods/<版本>/<运行编号>/`：原始运行、日志、轨迹、恢复状态和中间产物，不提交 Git。
- 历史 V17–V19 保留 `pilot/`、`formal/`、`archive/` 阶段层，避免将试运行、正式运行或历史重试混为一谈。旧 `experiments/archive/<版本>` 归入 `archive/legacy/`，不覆盖原有 archive。
- benchmark 构建产物、ST-Web POC 和仓库整理审计不属于这些方法运行，仍在各自目录。

## 启动与恢复

V17/V18 的正式运行脚本被冻结清单逐字节绑定，因此保留原文件。新的入口通过原有 `--output` 参数指定统一目录，不更改运行算法、模型参数、run/resume 规则或冻结摘要。

```sh
# 仅打印命令，不调用模型，不创建运行目录。
python scripts/run_method.py v18-v4 --run-id v18_example_001 --print-command -- --run

# V18 原入口默认为 preflight；传 --run 才运行模型。
python scripts/run_method.py v18-v4 --run-id v18_example_001

# 新 V19 运行；配置模式和参数仍由原运行器校验。
python scripts/run_method.py v19 --run-id v19_example_001 -- run --config experiments/methods/v19/v19_run/config/pilot.json

# 恢复已有正式运行时，必须指定其现有阶段位置；恢复资格仍由原运行器检查。
python scripts/run_method.py v19 --run-id v19_memory_formal_003 --stage formal -- resume
```

入口支持 `v17`、`v18`、`v18-v4`、`v19`、`v20`，分隔符 `--` 后的参数原样传给原脚本。已有其他模块入口继续使用其原有输出参数，显式传入 `artifacts/methods/<版本>/<运行编号>`。例如 V01–V14 的历史配置和默认输出会经兼容链接写入同一份新位置数据。

目录迁移不证明任何历史运行可以在当前源码下继续执行。当前源码有原先已存在的漂移时，旧运行器应继续拒绝恢复，不能通过更新冻结摘要绕过检查。

## 兼容入口

`experiments/v17`、`v18`、`v19`、旧 archive、V15/V16 的旧 run 目录，以及旧的 `artifacts/<运行编号>` 现在是相对符号链接。历史 JSON 内的绝对/相对路径保持原字节，链接使它们读取新位置的同一份材料。

这些链接不保存副本，不能当作冗余数据删除。日常从此索引和各版本 README 进入；新运行使用上方入口或显式的新输出路径。原始材料只存在本机，Git 中的配置和导航不能替代数据备份。

## 按版本查看

- [v01 方法说明](v01/README.md) · [本机运行材料](../../artifacts/methods/v01)
- [v02 方法说明](v02/README.md) · [本机运行材料](../../artifacts/methods/v02)
- [v03 方法说明](v03/README.md) · [本机运行材料](../../artifacts/methods/v03)
- [v04 方法说明](v04/README.md) · [本机运行材料](../../artifacts/methods/v04)
- [v05 方法说明](v05/README.md) · [本机运行材料](../../artifacts/methods/v05)
- [v06 方法说明](v06/README.md) · [本机运行材料](../../artifacts/methods/v06)
- [v07 方法说明](v07/README.md) · [本机运行材料](../../artifacts/methods/v07)
- [v08 方法说明](v08/README.md) · [本机运行材料](../../artifacts/methods/v08)
- [v09 方法说明](v09/README.md) · [本机运行材料](../../artifacts/methods/v09)
- [v10 方法说明](v10/README.md) · [本机运行材料](../../artifacts/methods/v10)
- [v11 方法说明](v11/README.md) · [本机运行材料](../../artifacts/methods/v11)
- [v12 方法说明](v12/README.md) · [本机运行材料](../../artifacts/methods/v12)
- [v13 方法说明](v13/README.md) · [本机运行材料](../../artifacts/methods/v13)
- [v14 方法说明](v14/README.md) · [本机运行材料](../../artifacts/methods/v14)
- [v15 方法说明](v15/README.md) · [本机运行材料](../../artifacts/methods/v15)
- [v16 方法说明](v16/README.md) · [本机运行材料](../../artifacts/methods/v16)
- [v17 方法说明](v17/README.md) · [本机运行材料](../../artifacts/methods/v17)
- [v18 方法说明](v18/README.md) · [本机运行材料](../../artifacts/methods/v18)
- [v19 方法说明](v19/README.md) · [本机运行材料](../../artifacts/methods/v19)
- [v20 方法说明](v20/README.md) · [本机运行材料](../../artifacts/methods/v20)
- [v21 方法说明](v21/README.md) · [本机运行材料](../../artifacts/methods/v21)
