# phase_a_unified_v14_step1_pilot

[返回 v14](../README.md)

## 已归位材料

- [reports](reports)

冻结配置和 JSON 结果保留原始字节；内部历史路径经兼容链接指向当前材料。配置状态不是新的完成声明。
