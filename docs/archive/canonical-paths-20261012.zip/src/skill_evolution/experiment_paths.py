"""Resolve relocated experiment files without rewriting frozen identities.

Only explicitly mapped repository paths move. Paths outside this checkout are
unchanged. This never substitutes archived bytes for reads.
"""
from functools import lru_cache
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


@lru_cache(maxsize=1)
def _relocations():
    rows = []
    for name in ('path-map.json', 'runtime-path-map.json'):
        mapping = json.loads((ROOT / 'experiments/methods' / name).read_text())
        rows.extend(mapping['relocations'])
    return sorted(rows, key=lambda row: len(row['old']), reverse=True)


def resolve_experiment_path(value):
    """Return the current filesystem location; leave the input identity intact."""
    path = Path(value)
    path = Path(os.path.abspath(path if path.is_absolute() else ROOT / path))
    try:
        name = path.relative_to(ROOT).as_posix()
    except ValueError:
        return path
    for row in _relocations():
        old = row['old']
        if name == old or name.startswith(old + '/'):
            return ROOT / (row['new'] + name[len(old):])
    return path
