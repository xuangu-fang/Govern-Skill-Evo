"""Verify direct paths, retired links, and the recorded path-only migration."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    receipt = json.loads((ROOT / 'experiments/methods/canonical-migration.json').read_text())
    errors = []
    archive_path = ROOT / receipt['snapshot']
    if digest(archive_path) != receipt['snapshot_sha256']:
        raise ValueError('Canonical-path snapshot checksum mismatch')
    with zipfile.ZipFile(archive_path) as archive:
        for row in receipt['files']:
            if hashlib.sha256(archive.read(row['old'])).hexdigest() != row['before_sha256']:
                errors.append('Snapshot changed: ' + row['old'])
            path = ROOT / row['new']
            if not path.is_file() or digest(path) != row['after_sha256']:
                errors.append('Current file changed: ' + row['new'])
    for name, expected in receipt.get('created_files', {}).items():
        path = ROOT / name
        if not path.is_file() or digest(path) != expected:
            errors.append('Created file changed: ' + name)
    for row in receipt['removed_links']:
        path = ROOT / row['entry']
        if path.exists() or path.is_symlink():
            errors.append('Old alias recreated: ' + row['entry'])
        if not (ROOT / row['target']).exists():
            errors.append('Alias target lost: ' + row['target'])
    symlinks = []
    for directory, dirs, files in os.walk(ROOT, followlinks=False):
        dirs[:] = [name for name in dirs if name not in
                   ('.git', 'external', '__pycache__', '.pytest_cache', '.venv')]
        for name in dirs + files:
            path = Path(directory) / name
            if path.is_symlink():
                symlinks.append(path.relative_to(ROOT).as_posix())
    errors.extend('Project symlink remains: ' + name for name in symlinks)
    # Only active code/config is checked here. Immutable evidence and migration
    # receipts retain old identity strings; history-resolution tests exercise them.
    rows = json.loads((ROOT / 'experiments/methods/canonical-paths.json').read_text())['relocations']
    pattern = re.compile('|'.join(re.escape(row['old']) + r'(?=/|[\s\x22\x27]|$)' for row in rows))
    for name in receipt['active_files']:
        path = ROOT / name
        if path.is_file() and pattern.search(path.read_text()):
            errors.append('Legacy path in active file: ' + name)
    for name, expected in receipt['preserved_logs'].items():
        if digest(ROOT / name) != expected:
            errors.append('Preserved experiment log changed: ' + name)
    return dict(files_checked=len(receipt['files']), removed_links=len(receipt['removed_links']),
                project_symlinks=len(symlinks), active_files_checked=len(receipt['active_files']),
                errors=errors)


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    result = verify()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return int(bool(result['errors']))


if __name__ == '__main__':
    raise SystemExit(main())
