"""Follow later path migrations when checking earlier, immutable receipts."""
import json
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=1)
def latest():
    path = ROOT / 'experiments/methods/canonical-migration.json'
    return json.loads(path.read_text()) if path.exists() else {'files': [], 'removed_links': []}


@lru_cache(maxsize=1)
def relocations():
    return json.loads((ROOT / 'experiments/methods/canonical-paths.json').read_text())['relocations']


def current(name):
    for row in relocations():
        if name == row['old'] or name.startswith(row['old'] + '/'):
            return row['new'] + name[len(row['old']):]
    return name


@lru_cache(maxsize=1)
def digest_changes():
    return {(row['new'], row['before_sha256']): row['after_sha256']
            for row in latest()['files']}


def expected_digest(name, expected):
    return digest_changes().get((current(name), expected), expected)


def retired(name):
    return any(name == row['entry'] or name.startswith(row['entry'] + '/')
               for row in latest()['removed_links'])
