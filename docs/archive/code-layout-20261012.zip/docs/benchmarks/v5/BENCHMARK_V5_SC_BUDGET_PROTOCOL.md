# Benchmark v5 提高输出额度后的工程闭环协议

2026-10-11。用户在确认两次8192 token推理截断后，授权适度提高输出额度，重跑真实S0→S1→S2工程闭环。本补充取代此前“不再追加调用”的运行限制；两次旧运行与历史结果不改写。

## 唯一预算调整

相对sc-engineering-20261011-002的low配置，每次执行及每次Skill编辑的max_tokens由8192提高到16384。单episode累计completion仍32768、累计prompt仍240000，最多12次模型响应和40次工具操作、等待600秒、无自动重试。实际执行请求额度为16384与剩余episode额度中的较小值。保持deepseek-v4-flash、temperature=0.2、reasoning_effort=low；不同时改变提示、任务、工具、反馈和评分，避免把多项修改混为预算影响。

## 固定范围

沿用统一S/C协议的两个Train批次和两个Monitor案例。完整重跑10个episode：S0/S1/S2各2条Monitor，S0/S1各2条Train；仅2次Skill编辑。S0重新从公开通用原则开始；不把旧运行结果或截断推理注入Skill。更新器仅看上一版Skill及本轮真实Train的公开请求、动作、工具结果和统一S/C反馈。Monitor不回流更新器，不择优追加轮次。没有Raw、Oracle或最终独立Test。

本次仍是工程验证，不把4条Train当完整可辨识训练集，也不把两个已知开发Monitor当泛化证据。预算变化前后不构成同预算效果比较。

## 记录和验证

新入口benchmark_v5_sc.pilot_budget，产物sc-engineering-20261011-003。执行前冻结配置、代码、案例和协议；继承历史保护清单并保护前次中断目录和既有v5文档。旧current入口、旧评价器、旧任务及结果全部保留。

执行结束后逐轨迹重放、重评分、重建模型输入；核对S1/S2来自指定Train和真实模型输出、没有人工改写、没有Monitor反馈进入学习输入。报告实际截断、停止状态、模型调用和tokens；不把缺测当0分或把模拟Skill当真实产物。正常业务失败不阻止Skill更新；基础设施异常、供应方超预算、截断及编辑器无有效文本仍按原运行器规则停止并保留现场，不静默补跑到通过。如另需处理截断传播，必须明确记录为协议修订。

复现入口：`PYTHONPATH=src python3 -m benchmark_v5_sc.pilot_budget freeze`，随后分别运行`run`、`validate`。已有冻结目录禁止重复freeze，已完成任务只读恢复，不覆盖轨迹。
