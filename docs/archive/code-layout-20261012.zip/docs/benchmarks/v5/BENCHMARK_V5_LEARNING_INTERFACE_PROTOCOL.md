# Benchmark v5 学习型接口修订复核协议

2026-10-11 · 独立接口诊断，后验触发、执行前冻结

原学习校准出现两项可确认的接口问题：预测工具的docstring同时描述LS1/LG1，部分模型使用`{LS1:{...}}`或`{LG1:{...}}`包装；原评价器仅按顶层字段取值，导致明确预测未被覆盖率统计捕获。另有完整规则Agent反复复用同一operation_id于不同接口，收到冲突后查询既有凭证而不创建新号；LG1公开文本没有充分解释该号由Agent自行产生。这些不能当作隐藏业务规则难度。

接口0.2位于新增`interface_revision.py`，保留0.1源码和全部原始评分。仅做两项变更：LS1改为每个商品一个强类型`predict_return(item_id,refund_cents,available_on_acceptance)`；LG1改为单布尔`predict_documents(available_documents_sufficient)`。二者都不返回正确答案，也不影响S/C。公开请求补充：每个新写操作自行选新的非空operation_id；只有相同接口/载荷重试才复用，receipt_id仍须使用真实回执。业务规则、任务、状态转换、授权、评分函数及执行预算不改。

独立选定4格：LS-H1、LS-H4、LG-H4、LG-H5，均为oracle完整规则、单次执行。它们覆盖金额预测、边界预测、补件依据记录和正常办理依据记录。复用既有oracle状态，不调用新学习器。选择基于已见接口问题，因此不是盲测、不是额外学习成绩，也不与原44格合并；不能把改善归因于经验学习。

参数沿用600秒等待补充：Flash、temperature0.2、reasoning_effort high、单次8192/累计32768 completion、24轮/60工具，并发2。主实验运行完后再启动这4格，避免实际并发超过2。不因失败追加重复；报告真实完成率、预测覆盖率、操作号冲突数、预算异常及重放结果。

原0.1预测另可做**后验格式敏感性审计**：仅接受原生顶层字段或唯一匹配机制的LS1/LG1外层包装，不修正数值、布尔值或缺失项；有冲突的双重表示标为歧义，不按答案挑选表示。原记录和分数不改。未经校准的预测缺失不能等同于知识缺失。

新增入口在独立进程中通过显式环境适配复用冻结执行循环；版本、源码、工具目录、原始输入及结果均另行归档于`learning-interface-20261011-003`。不影响正在执行的0.1实验。复现命令：

```bash
PYTHONPATH=src python -m unittest discover -s tests/benchmark_v5_learning -v
PYTHONPATH=src python -m benchmark_v5_learning.interface_probe freeze
PYTHONPATH=src python -m benchmark_v5_learning.interface_probe run
PYTHONPATH=src python -m benchmark_v5_learning.interface_probe validate
```
