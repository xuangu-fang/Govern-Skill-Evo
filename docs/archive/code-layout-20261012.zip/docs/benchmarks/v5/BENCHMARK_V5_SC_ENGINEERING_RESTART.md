# Benchmark v5 工程试跑推理强度调整

首个固定high推理运行在S0首个Monitor任务发生单次8192 token截断，未执行业务写入；已停止后续任务，未生成S1/S2。原始运行保留于sc-engineering-20261011-001，不覆盖、不作为有效业务难度或Skill效果证据。3次真实请求共15961 tokens，无未知usage。

本次只允许一次独立工程重启，使用deepseek-v4-flash、reasoning_effort=low；任务矩阵、公开提示、S0、训练反馈、两次更新、token上限、停止条件均沿用统一评价协议。保留high失败，不与low运行合并比较。目的仅是检查在相同资源上限下能否完成闭环，不是降低任务难度、改善Skill成绩或寻找最佳超参数。

新目录sc-engineering-20261011-002、新入口benchmark_v5_sc.pilot_low，执行前冻结。仍最多10次业务执行和2次编辑调用，完成后停止；若再次截断或运行失败，则只报告工程阻碍，不再追加第三次模型尝试、不增加预算直到通过。无最终Test、无Oracle、无Raw实验。

继承统一S/C协议及历史保护清单，并将首个中断目录全部纳入保护。使用新目录的protocol.json记录实际low配置，来源哈希包含本补充及新入口。旧high配置不修改。复现使用`PYTHONPATH=src python3 -m benchmark_v5_sc.pilot_low freeze/run/validate`，其中三个动作分别调用，已冻结目录禁止重复freeze。
