# Benchmark v5 学习型校准等待预算补充协议

2026-10-11 · 在任何留出episode执行前冻结

原协议`learning-20261010-001`的首个LS1归纳请求连续两次HTTP等待180秒后超时，未得到可归档响应或usage。第二次是原协议允许的一次相同请求重试；没有学习状态生成，也没有留出题执行。原目录、冻结文件与两个失败尝试完整保留。只读模型列表请求HTTP200且列出Flash；随后单独的“OK”诊断调用以同模型、temperature=0.2、reasoning_effort=high返回，1.2513秒、109 tokens（88 prompt＋21 completion）。该诊断不参与学习或Benchmark计分。

补充运行`learning-20261011-002`**仅将HTTP等待上限由180秒改为600秒**。模型、提示词、学习输入、实例、44个预注册执行、2个归纳逻辑调用、调度顺序、token与工具预算、重试规则、评分全部继承。超过180秒的可完成响应不应被误判为业务学习困难；此更改不增加模型可生成token或可用业务信息。所有条件采用同一等待设置。

沿用原代码，通过新增`supplement.py`显式选择新的配置与目录；不改原冻结源码。新freeze附加补充协议、配置、入口测试及复制输入的摘要；原freeze纳入谱系。训练公开投影逐字内容相同，2个归纳产物仍须在任何留出执行前全部冻结，之后禁止人工纠正。

原运行状态为`infrastructure_aborted_before_learning_state`，不能计为0分、不能宣称完成44次。原两个超时尝试成本未知，独立于补充运行已知usage报告；不得把客户端超时当成服务端零消耗。若600秒仍失败，保留外部阻塞，不再无限延长等待或改题直到通过。若仅部分条件失效，真实结果与缺测分开，不能填补或替换失败。

```bash
PYTHONPATH=src python -m unittest discover -s tests/benchmark_v5_learning -v
PYTHONPATH=src python -m benchmark_v5_learning.supplement freeze
PYTHONPATH=src python -m benchmark_v5_learning.supplement prepare
PYTHONPATH=src python -m benchmark_v5_learning.supplement run
PYTHONPATH=src python -m benchmark_v5_learning.supplement validate
PYTHONPATH=src python -m benchmark_v5_learning.supplement analyze
```

原协议仍是任务/指标定义的依据；本补充只取代HTTP等待条款。结果报告同时披露两个运行目录、冻结时刻和接口诊断，不能把补充结果当作原180秒预算的结果。
