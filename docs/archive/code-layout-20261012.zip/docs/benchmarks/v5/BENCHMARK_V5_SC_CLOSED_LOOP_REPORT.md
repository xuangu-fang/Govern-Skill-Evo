# Benchmark v5 真实 Skill 两轮工程闭环报告

2026-10-11。提高单次输出额度后，deepseek-v4-flash 的真实 S0→S1→S2 闭环已完成：10条业务执行、2次Skill更新，全部完成重放、评分和输入隔离核验。本次只证明工程链路可运行，没有使用最终独立Test，不构成正式自进化效果实验。两次旧8192截断运行和VPN连接失败记录均保留。

## 配置与运行沿革

按用户授权，将执行Agent与Skill更新器的单次输出上限由8192提高至16384 tokens，单episode累计completion仍32768、累计prompt仍240000；模型deepseek-v4-flash、temperature=0.2、reasoning_effort=low、工具/提示/案例/S0/统一S/C评价器均不变。固定两轮：每轮2条Train，S0/S1/S2各执行同一2条Monitor，不追加第三轮。

[预算补充协议](BENCHMARK_V5_SC_BUDGET_PROTOCOL.md)冻结的003运行首次请求因VPN未连接发生URLError，无模型响应、无工具操作，score=null；用户恢复VPN后确认继续。模型列表接口返回200且Flash可用，004在相同配置下重新开始，003完整保留并纳入保护。004的freeze.json记录用户恢复连接及不改配置的依据，两个目录protocol.json逐字段一致。

## 闭环结果

| Skill | Monitor S | Monitor C | Monitor S∧C |
|---|---:|---:|---:|
| S0 | 2/2 | 2/2 | 2/2 |
| S1 | 2/2 | 1/2 | 1/2 |
| S2 | 1/2 | 2/2 | 1/2 |

第一轮Train中，供应商5天凭证案例S/C均通过；承运方5天凭证案例S=true、C=false。模型基于S0及这两条真实执行与反馈生成S1，原样保存。第二轮Train使用S1执行供应商10天及意外原因案例，两条均S=true、C=false；模型基于S1及本轮Train生成S2，原样保存。没有人工修订Skill或把Monitor错误加入学习输入。

S1的承运方案例完成了补件，但依据只记录了W，未形成支持补件方案的充分相关依据，所以C=false。S2对供应商2天、当前材料已充分的Monitor申请I补件，C=true而S=false；其Skill把两条新失败过度归纳为缺I就应补件。系统能够记录版本退化，不能把“完成两轮”描述为“自进化改善了成绩”。

这也不是充分的双维研究结果：Monitor仅两个已知开发结构，S0本轮即满分；四条Train不能辨识全部规律，尤其不能推断精确时效阈值。S1/S2仍有过度归纳，不代表完整学习。此处不据少量结果给方法排名、不正式认定I/K场景、不再围绕LG1追加优化。

## 输出预算与成本

004共53次有响应模型调用：51次业务执行调用、2次Skill更新。合计346154 tokens，其中prompt 264498、completion 81656；此处为整轮所有请求求和，不能与单episode额度混淆。0次截断、0次供应方超请求预算、0次累计预算异常、0次基础设施无效episode、0次自动重试。

S2更新实际completion为10982，其中reasoning为10389，finish_reason=stop，正常生成新版文本；它超过旧8192上限而处于新16384上限内。这提供了本次更大额度确实被使用的直接证据。其他响应未超过8192。不能据此声称提高额度普遍改善业务能力，预算前后并非同预算效果对照。

此前003的1次无响应连接请求单列，原始usage缺失，不混进有效运行token总数。旧001/002截断结果也不并入004成绩。

## 核验

14项工程与预算协议测试通过，包括配置差异检查、独立输出目录、四象限、反馈边界、模拟闭环与中断；真实模型成绩来自004原始响应，与模拟测试分开。

10条真实轨迹逐事件精确重放、重评分和执行模型输入重建一致。两次编辑请求分别由规定的Train投影与上一版Skill重新构造，和原请求完全一致；S1/S2文本与模型原始输出一致，状态哈希一致。Train与Monitor使用同一learning-sc-1.0评价器，Monitor没有把私有反馈回传执行Agent，也没有进入更新器输入。工具目录中没有文件系统或独立Test访问能力。

10741个已登记历史保护文件摘要不变，旧v4/v5代码、任务、冻结协议与结果没有覆盖。执行配置、Skill更新配置及实际响应模型均核对；新产物只写在004及本报告中。停止策略未改变，本轮没有再次触发截断，因此“遇到截断后的自动反馈与恢复”仍未实现；本次完成的是提高预算后正常结束的两轮闭环。

## 产物与复核入口

- [原始运行目录](../../../artifacts/benchmarks/v5/sc-engineering-20261011-004)
- [验证结果](../../../artifacts/benchmarks/v5/sc-engineering-20261011-004/validation.json)
- [预算及逐例诊断](../../../artifacts/benchmarks/v5/sc-engineering-20261011-004/diagnostics.json)
- [S0](../../../artifacts/benchmarks/v5/sc-engineering-20261011-004/states/S0.md)、[S1](../../../artifacts/benchmarks/v5/sc-engineering-20261011-004/states/S1.md)、[S2](../../../artifacts/benchmarks/v5/sc-engineering-20261011-004/states/S2.md)

004沿用已冻结budget入口，指定独立目录复核，不调用模型：

```sh
PYTHONPATH=src python3 - <<'PY'
from benchmark_v5_sc import pilot_budget as p
p.DEST = p.ROOT / 'artifacts/benchmarks/v5/sc-engineering-20261011-004'
p.run_action('validate')
PY
```

## 下一阶段

统一S/C、历史重评、LG1最小真实工程闭环三步现已完成。按既定顺序转向扩展和验证不同Success学习机制及不同结构的Compliance机制；有可靠S/G证据后再探索I/K。任务体系相对完整后，才冻结正式Evolution/Monitor/独立Test并开展多轮效果实验。Benchmark继续独立于v21 Memory和具体Skill更新算法。
