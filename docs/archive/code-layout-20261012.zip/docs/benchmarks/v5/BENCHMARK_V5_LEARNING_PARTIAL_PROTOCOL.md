# Benchmark v5 学习产物失败时的独立条件执行补充

2026-10-11 · 在任何留出episode执行前冻结

600秒等待补充下，LS1首个归纳请求于2026-10-10 16:12:03 UTC返回：prompt 2750、completion 8192，全部completion为reasoning tokens，finish_reason=length，未产出可携带文本。该尝试花费及原响应保留；这是归纳预算失败，不是业务S/C分数。不能用空文本冒充成功学习、人工补规则或无限增加预算直到产出。

原运行器在任何学习失败时立即停止全部条件。新增独立续行入口`recover.py`允许其余信息条件继续，**不改变任何任务、观察、提示、模型、token/等待预算或评分**。已有LS1归纳不重跑；LG1仍只执行其预注册的单次归纳逻辑调用。成功产物原样封存，失败产物登记reason与原响应摘要，无可携带状态。

每个机制的zero/raw/oracle及已注册prefix条件可独立执行。只有需要缺失学习状态的processed格记为upstream_learning_invalid、executed=false、score=null，不发送模型执行请求，也不算业务失败。依赖失败产物的格数明确列出，不能宣称44次都真实执行或填补成绩。所有可用状态及失败来源在留出执行前共同冻结。

数据、规则、主协议与600秒补充已冻结且保持不变。新增入口、测试和本补充另存execution_extension_freeze摘要。验证时对真实执行逐轨迹重放/重评分，对未执行格检查无trace/audit及API次数为0；报告分别列计划数、真实执行数、有效数和缺测数。若后续要研究更大归纳预算，必须另设实验，不混入本轮。

```bash
PYTHONPATH=src python -m unittest discover -s tests/benchmark_v5_learning -v
PYTHONPATH=src python -m benchmark_v5_learning.recover freeze
PYTHONPATH=src python -m benchmark_v5_learning.recover prepare
PYTHONPATH=src python -m benchmark_v5_learning.recover run
PYTHONPATH=src python -m benchmark_v5_learning.recover validate
PYTHONPATH=src python -m benchmark_v5_learning.recover analyze
```
